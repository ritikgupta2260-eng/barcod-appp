import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:csv/csv.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

void main() {
  runApp(const BarcodeLookupApp());
}

class BarcodeLookupApp extends StatelessWidget {
  const BarcodeLookupApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Barcode Lookup',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Product {
  final String barcode;
  final String name;
  final String mrp;
  final String srate;

  Product({
    required this.barcode,
    required this.name,
    required this.mrp,
    required this.srate,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Map<String, Product> _db = {};
  bool _loading = true;
  String? _lastScanned;

  @override
  void initState() {
    super.initState();
    _loadCsv();
  }

  Future<void> _loadCsv() async {
    try {
      final raw = await rootBundle.loadString('assets/products.csv');
      final rows = const CsvToListConverter(eol: '\n').convert(raw, shouldParseNumbers: false);

      if (rows.isEmpty) {
        throw Exception('CSV is empty');
      }

      final header = rows.first.map((e) => e.toString().trim().toLowerCase()).toList();
      final bIdx = header.indexOf('barcode');
      final pIdx = header.indexOf('product');
      final mIdx = header.indexOf('mrp');
      final sIdx = header.indexOf('srate');

      if ([bIdx, pIdx, mIdx, sIdx].any((i) => i == -1)) {
        throw Exception('CSV header must contain Barcode, Product, MRP, SRate');
      }

      for (var i = 1; i < rows.length; i++) {
        final row = rows[i].map((e) => e?.toString() ?? '').toList();
        if (row.length <= bIdx) continue;
        final barcode = row[bIdx].trim();
        if (barcode.isEmpty) continue;
        final product = row.length > pIdx ? row[pIdx].trim() : '';
        final mrp = row.length > mIdx ? row[mIdx].trim() : '';
        final srate = row.length > sIdx ? row[sIdx].trim() : '';
        _db[barcode] = Product(barcode: barcode, name: product, mrp: mrp, srate: srate);
      }
    } catch (e) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showError('Failed to load CSV: \$e');
      });
    } finally {
      setState(() => _loading = false);
    }
  }

  void _showError(String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('OK'))
        ],
      ),
    );
  }

  void _onDetect(BarcodeCapture capture) {
    final List<Barcode> barcodes = capture.barcodes;
    if (barcodes.isEmpty) return;
    final code = barcodes.first.rawValue ?? '';
    if (code.isEmpty) return;

    if (_lastScanned == code) return;
    _lastScanned = code;

    final product = _db[code];
    if (product != null) {
      _showProduct(product);
    } else {
      _showNotFound(code);
    }

    Future.delayed(const Duration(seconds: 2), () {
      _lastScanned = null;
    });
  }

  void _showProduct(Product p) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(p.name),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _infoRow('Barcode', p.barcode),
            const SizedBox(height: 6),
            _infoRow('MRP', p.mrp),
            const SizedBox(height: 6),
            _infoRow('SRate', p.srate),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Close')),
        ],
      ),
    );
  }

  void _showNotFound(String code) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Not found'),
        content: Text('Barcode "\$code" not found in database.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('OK')),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Row(
      children: [
        Expanded(child: Text('\$label:', style: const TextStyle(fontWeight: FontWeight.bold))),
        Expanded(child: Text(value, textAlign: TextAlign.right)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Barcode Lookup'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          const SizedBox(height: 8),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Text('Tap START SCAN and point camera at a barcode.'),
          ),
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.black26),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: MobileScanner(
                  allowDuplicates: false,
                  onDetect: _onDetect,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 18),
            child: Row(
              children: [
                ElevatedButton.icon(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Point camera at barcode to scan')),
                    );
                  },
                  icon: const Icon(Icons.camera_alt),
                  label: const Text('Start Scan'),
                ),
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: () {
                    final count = _db.length;
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Database'),
                        content: Text('Loaded \$count products from CSV.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('OK')),
                        ],
                      ),
                    );
                  },
                  icon: const Icon(Icons.storage),
                  label: const Text('DB Info'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
